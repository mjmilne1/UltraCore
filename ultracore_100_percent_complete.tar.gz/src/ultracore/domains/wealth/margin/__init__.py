"""Margin Lending Service"""
from .margin_service import MarginLendingService

__all__ = ["MarginLendingService"]
