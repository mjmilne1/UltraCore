"""Integration with Existing Modules"""
from .ultraoptimiser_adapter import UltraOptimiserAdapter

__all__ = ["UltraOptimiserAdapter"]
