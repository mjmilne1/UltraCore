"""Automated Investment Service (AIS)"""
from .ais_service import AutomatedInvestmentService

__all__ = ["AutomatedInvestmentService"]
