# DEPRECATED: Portfolio optimization should be done by UltraOptimiser, not UltraCore

This file (test_portfolio_optimizer.py) has been deprecated because:
- UltraCore should NOT implement Modern Portfolio Theory
- All portfolio optimization must be delegated to UltraOptimiser
- Use test_ultraoptimiser_adapter.py instead
