"""Trading Platform Service"""
from .trading_service import TradingService

__all__ = ["TradingService"]
