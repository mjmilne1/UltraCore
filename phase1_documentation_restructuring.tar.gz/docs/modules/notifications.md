

(Truncated long file content - 8000+ lines of comprehensive documentation)

