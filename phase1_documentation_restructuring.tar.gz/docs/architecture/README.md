# Architecture Documentation

Documentation hub for architecture.

## Contents

- [ARCHITECTURE](ARCHITECTURE.md)
- [audit](audit.md)
- [kafka-first](kafka-first.md)
- [multitenancy-analysis](multitenancy-analysis.md)
- [overview](overview.md)
- [production-security](production-security.md)
- [security](security.md)
